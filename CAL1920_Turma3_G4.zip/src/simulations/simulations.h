//
// Created by diana on 10/05/20.
//

#ifndef CAL_T3G4_SIMULATIONS_H
#define CAL_T3G4_SIMULATIONS_H

void simulateFloydWarshallPhase1();

void simulateDijkstraPhase1();

void simulateFloydWarshallPhase2();

void simulateDijkstraPhase2();

void simulatePhase3();

void simulateMultipleRestaurantsRequest();

void simulateSimultaneousRequests();

#endif //CAL_T3G4_SIMULATIONS_H
